module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "",
  DB: "react_photo_db"
};